#ifdef __cplusplus
extern "C" {
#endif


int wcsicmp(const wchar_t *s1, const wchar_t *s2);
int wcsnicmp(const wchar_t *s1, const wchar_t *s2, size_t n);


#ifdef __cplusplus
}
#endif
