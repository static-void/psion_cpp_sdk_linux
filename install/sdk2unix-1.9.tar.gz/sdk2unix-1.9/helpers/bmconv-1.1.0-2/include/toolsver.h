// TOOLSVER.H
// 
// Copyright (c) 1997-2001 Symbian Ltd.  All rights reserved.
//

#ifndef __TOOLSVER_H__
#define __TOOLSVER_H__

const int version=110;

#endif

