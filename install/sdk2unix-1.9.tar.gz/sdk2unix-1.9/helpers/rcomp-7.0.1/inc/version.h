// VERSION.H
//
// Copyright (c) 1997-1999 Symbian Ltd.  All rights reserved.
//

const char version[]="7.01";

// end of version.h
