// TOKENS.H
//
// Copyright (c) 1997-1999 Symbian Ltd.  All rights reserved.
//

class StructItem;
class SimpleStructItem;
class ArrayStructItem;
class StructArrayStructItem;
class StringArray;
class yy_scan;

#include "rcomp.hpp"
