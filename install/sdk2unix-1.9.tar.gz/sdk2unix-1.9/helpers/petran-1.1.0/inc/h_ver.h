// H_VER.H
//
// Copyright (c) 1996-2001 Symbian Ltd.  All rights reserved.
//

#ifndef __H_VER_H__
#define __H_VER_H__
const TInt MajorVersion=1;
const TInt MinorVersion=0;
const TInt Build=175;
const char Copyright[]="Copyright (c) 1996-2001 Symbian Ltd.\n\n";
#endif

