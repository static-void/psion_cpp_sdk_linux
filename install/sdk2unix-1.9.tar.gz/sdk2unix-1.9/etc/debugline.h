#ifndef __DEBUGLINE_H
#define __DEBUGLINE_H

extern void debugline(const char *a, ...);
#define DEBUGLINE debugline("%s:%s: %d", __BASE_FILE__, __FUNCTION__, __LINE__)
#define PRINTMEM { TInt avtot, avbig, tot, nel; nel = User::Heap().AllocSize(tot); avtot = User::Heap().Available(avbig); debugline("%s:%s: %d #:%d, Sum:%d, Av:%d(%d)", __BASE_FILE__, __FUNCTION__, __LINE__, nel, tot, avtot, avbig); }
#define DEBUGMEM { PRINTMEM User::Heap().Check(); }

#endif
