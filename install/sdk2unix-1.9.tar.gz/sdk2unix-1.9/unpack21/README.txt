README
unpack21
Unpack the Nokia 2.1 SDK for Symbian C++
by Simon Woodside

1. What you need

cabextract tool
- for extracting .CAB archives
- available as a fink package

S60_SDK_2_1_NET.zip package
- the S60 SDK installer for Windows
- available from Forum Nokia
- http://www.forum.nokia.com/
- the URL to the package changes from time to time
- navigate to Tools and SDKs, Symbian/C++, 
  Series 60 SDKs for Symbian OS, Nokia Edition
- download v2.1, Borland & Microsoft, 115 MB

this package
- for extracting the S60 SDK on unix

2. How to unpack

- create the following directory hierarchy:
sdk21/
sdk21/unpack21/
sdk21/S60_SDK_2_1_NET.zip
- cd sdk21
- ./unpack21/unpack21.sh

3. Contact

Simon Woodside
<sbwoodside@yahoo.com>
http://simonwoodside.com
