#!/usr/bin/perl
#
# fixsdk.pl   (C) 2001 Alfred E. Heggestad
#
# based on O. Flebbe's 'copysdk.pl'
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#

use File::Copy;

if ($#ARGV != 0) {
    printf STDERR "usage: fixsdk from\n";
    exit( 1);
}

$from=$ARGV[0];

$/="\r\n";
    

#
# recursively lowercase all files in given directory
#    
sub movedir {
    my ($dir) = @_; # 1 argument
    my ($i, $j);
    my @dir;

    # lowercase this directory first
    my $dir_ = lc $dir;
    rename $dir, $dir_;
    print "renaming dir: $dir -> $dir_\n";
    $dir = $dir_;

    opendir IN, $dir;
    @dir = readdir IN;
    closedir IN;

    foreach $i (@dir) {
	if (($i eq ".") || ($i eq "..")) { # skip '.' and '..'
	    next;
	}
	$j = $i;
	$j =~ tr/[A-Z]/[a-z]/;  # force to lower case
	$i = "$dir/$i";
	$j = "$dir/$j";

	if (-f $i) { # file
	  rename $i, $j;
	} elsif ( -d $i) { # directory
	  &movedir($i);
	} else {
	    print STDERR "problems: $i\n";
	}
    }
}

$from =~ s/\/$//;

mkdir  $to, 0777;

#
# recursively lowercase files
#
&movedir( $from );


# EOF - fixsdk.pl
