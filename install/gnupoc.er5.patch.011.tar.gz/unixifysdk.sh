#! /bin/bash
#
# unixifysdk.sh - Make the EPOC SDK useful for Unix
#
# (c) 2000-2001 Alfred E. Heggestad 
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#
# This program does the following:
#
#   o Sets the apropriate file attributes
#   o Rename all files to lowercase
#   o Convert all files from DOS to Unix
#

# TODO exit if EPOCROOT not set
echo using EPOCROOT=$EPOCROOT

#
# setting file attributes
#
echo 'Setting file attributes for pre installation'
chmod -R 755 $EPOCROOT

#
# rename all files to lowercase only
#
echo 'Renaming files to lowercase'
perl $EPOCROOT/EPOC32/fixsdk.pl $EPOCROOT

#
# recursively convert MS-DOS files to Unix format.
# text files only
#
echo 'Converting text files to Unix format'
FILES=$(find . -name '*.cpp' -o -name '*.h' \
		-o -name '*.txt' -o -name '*.mmp' \
		-o -name '*.hrh' -o -name '*.ra' \
		-o -name '*.mbg' -o -name '*.rh' \
		-o -name '*.pm' -o -name '*.pl' \
		-o -name '*.ini' -o -name '*.sh' \
		-o -name '*.inl' -o -name '*.rsg' )

for n in $FILES
do echo doing $n
perl -pi -e 's/\r\n/\n/' $n
done


#
# setting file attributes
#
echo 'Setting file attributes for post installation'
chmod 555 $EPOCROOT/epoc32/release/marm/rel/*.*
chmod 555 $EPOCROOT/epoc32/release/marm/deb/*.*
chmod 555 $EPOCROOT/epoc32/release/wins/rel/*.*
chmod 555 $EPOCROOT/epoc32/release/wins/deb/*.*
chmod 555 $EPOCROOT/epoc32/include/*.*


echo 'Done'

# EOF - unixifysdk.sh
