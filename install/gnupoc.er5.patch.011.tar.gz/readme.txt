README.txt
----------

This is Gnupoc, EPOC toolchain for GNU/Linux.
Contact info: www.edmund.roland.org or edmund@roland.org
See HISTORY.TXT file for changes


LICENSE:
--------

The original EPOC ER5 C++ SDK is copyright Symbian Ltd.
This _patch_ is copyright Alfred E. Heggestad under the
terms of the GPL (General Public License)


INSTALLATION:
-------------

1.) install the Symbian ER5 SDK somewhere (use copy)
2.) unzip this archive to the epoc32/tools directory
3.) lowercase/uppercase some files.
4.) Set environment var $EPOCROOT to your SDK directory
5.) source epoc32/tools/setepocpath
6.) install WINE, the Windoz emu for Unix
7.) install the GCC compiler for target arm-pe, found at http://www.science-computing.de/o.flebbe/sdk/
    or recompile Gcc_113.zip for host linux, target arm-pe


USAGE:
------

1.) makmake project marm
2.) make -f project.marm
3.) send the binary file to your Symbian device and test it (using plptools)


USEFUL INFO:
------------

To avoid setting the env variable EPOCROOT all the time,
put the following in your ~/.bashrc file:

    # setting EPOCROOT and relevant path
    export EPOCROOT=<your epoc path>
    source $EPOCROOT/epoc32/tools/setepocpath

The paths also need to be set for WINE. Edit ~/.wine/config
or the wine.conf WINE configuration file to add a Windows
path to /epoc32/tools. (epoc32/gcc/bin is not needed)
Example: (from wine.cnf)

    [Drive X]
    "Path" = "<same as EPOCROOT>"
    "Type" = "network"
    "Label" = "My EPOC SDK"
    "Filesystem" = "win95"

    "Path" = "c:\\windows;c:\\windows\\system;e:\\;f:\\;f:\\bin;x:\\epoc32\\tools;"


If your program or some header file includes a file with wrong case,
e.g. #include <E32std.h> or #include <e32Std.H> or #include <E32BASE.H>
which only exist as 'e32std.h' (all lowercase of course), try
to make a softlink from e.g. 'E32STD.H' -> 'e32std.h'

    ln -s e32std.h E32STD.H




CONSIDERATIONS:
---------------

o All filenames must be *case sensitive*
  (except those used by .EXE's under WINE)
o MAKMAKE converts backslashes in MMP files to forward slash
  in makefiles.
o MMP Keywords must be in UPPERCASE


KNOWN BUGS:
-----------

o Generation of resource files does not work properly
o ARM binaries are not guaranteed to work [UPDATED: after remove -Wall flag it works better now!]
o relative paths in MMP files is not supported
o #include "..\dir\file.h" does not work (only forward slash works)
o Filenames with special characters (i.e. +) are problematic for WINS
o WINS/DEB does not work - problems with Program Database (.pdb)
o When building for WINS, sometimes it can fail at link-stage with
  this error: 'fatal error LNK1104: cannot open file "TEMPFILE" '
  This happens now&then, normally it helps to try again 3-4 times
o WINS for DLLs is not complete yet - needs fix at defmake stage
o Some binaries differ from binaries generated with Windows SDK
  Example:


EXAMPLES:
---------

Here are some examples you can try to test out the SDK patch
and the Gcc compiler for ARM. These should compile straight
away without tampering the original .mmp files.
They are all tested on Psion Series 5mx

/epoc32ex/comms/echoeng.mmp
/epoc32ex/dbms/dbcreate.mmp    OK
/epoc32ex/e32/euactiv1.mmp     OK
/epoc32ex/e32/euactiv2.mmp     OK
/epoc32ex/e32/euactiv3.mmp     OK
/epoc32ex/e32/euactiv4.mmp     OK
/epoc32ex/e32/euactiv5.mmp     OK
/epoc32ex/e32/euactiv6.mmp     OK
/epoc32ex/e32/euactiv7.mmp     OK
/epoc32ex/f32/fsasynch.mmp     OK
/epoc32ex/f32/fsconn.mmp       OK
/epoc32ex/f32/fsdir.mmp        OK
/epoc32ex/f32/fsdrive.mmp      OK
/epoc32ex/f32/fshello.mmp      OK
/epoc32ex/f32/fsparse.mmp      OK


CROSSCOMPILING GCC FOR ARM:
---------------------------

The source code for GCC and Gnu utilies should come with the
ER5 SDK Cd-rom. It is contained in a zip file in:

    \Zip\GCC_113.ZIP

Unzip this and do the following:

    cd src
    chmod -R 755 .
    ./configure --prefix=/usr/local/er5 --target=arm-pe

If compiling with GCC version 2.95.3 or later, you need
to remove the 'extern char *strdup();' in some files:

    src/binutils/arsup.c
    src/binutils/dlltool.c
    src/ld/mri.c
    src/ld/ldwrite.c

There are also some problems with these files:
    src/tcl/unix/tclUnixStr.c
    src/make/arscan.c
    src/make/dir.c             ; glob_dir_hook's

You can also get some more information about how to crosscompile GCC
for ARM here [2] and [3]


REPORTING-BUGS
--------------

If you want to report bugs or send improvements, please
send it in an ascii text formatted email to 'edmund@roland.org'
HTML formatted emails will not be read.

please provide the following information about your system:

o Which EPOC SDK you have (may where you got it from)
o ARM-gcc version (arm-pe-gcc --version)
o GNU make version (make --version)
o Output from ver_linux (e.g. /usr/src/linux/scripts/ver_linux)
o Generated makefiles (from MAKMAKE) or output from compiling code



NOTE:
-----

This is a preliminary hack and it will probably not work
'out of the box'. So therefore, patience, if you *really* want
to develop EPOC on your Linux machine.
There are still some problems regarding case-sensitivity, and
the APP's it builds are crashing during startup.
More info here: 


DESIGN GOALS FOR GnuPoc:
------------------------

o To generate GNU make files instead of Nmake files
o To be compatible with original SDK for Windows
o To be better than original SDK for Windows
o To be free speech (GPL) and free beer for the public
o To be easy to use and install (still a long way to go...)
 

REFERENCES:
-----------

[1]   www.symbiandevnet.com                           Developer Network, SDKs and more
[2]   www.koeniglich.de/linuxsdk.html                 Rudi Koeniglich's SDK for Linux
[3]   www.gumbley.demon.co.uk/gcc-epoc-notebook.txt   Matt Gumbley's notes on GCC/Epoc
[4]   plptools.sourceforge.net                        Homepage for PLP tools
[5]   gnupoc.sourceforge.net                          Homepage for this project
[6]   www.sourceforge.net/projects/gnupoc/            Homepage for this project



