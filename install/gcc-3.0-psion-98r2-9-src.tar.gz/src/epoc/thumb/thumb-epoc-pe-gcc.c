#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

void
error (progname, msg)
    char *progname;
    char *msg;
{
  fprintf(stderr, "%s: %s\n", progname, msg);
  exit(1);
}

void
cut_prefix (progname)
    char *progname;
{
  char *prefix = "thumb-epoc-pe-";
  int prefixlen = strlen (prefix);
  char *pos, *next;
  int i;

  pos = strstr (progname, prefix);
  if (!pos)
    error (progname, "program name must contain the prefix thumb-epoc-pe-");
  while (1)
    {
      next = strstr (pos + 1, prefix);
      if (!next)
        break;
      pos = next;
    }

  i = 0;
  while (1)
    {
      pos[i] = pos[prefixlen + i];
      if (!pos[i])
        break;
      i++;
    }
}

void
build_argv (argc, argv, new_argv)
    int argc;
    char **argv;
    char **new_argv;
{
  int i;
  
  new_argv[0] = argv[0];
  new_argv[1] = "-mthumb";
  for (i = 1; i < argc; i++)
    new_argv[i + 1] = argv[i];
  new_argv[argc + 1] = 0;
}

int
main (argc, argv)
    int argc;
    char **argv;
{
  char **gcc_argv;
  int gcc_retv;
  
  if (argc < 1)
    error ("thumb-epoc-pe-gcc", "argv[] must not be empty");

  gcc_argv = (char **)malloc (sizeof(char **) * (argc + 2));
  if (!gcc_argv)
    error (argv[0], "out of memory");

  cut_prefix (argv[0]);
  build_argv (argc, argv, gcc_argv);
  gcc_retv = execvp (gcc_argv[0], gcc_argv);

  free (gcc_argv);
  return gcc_retv;
}
