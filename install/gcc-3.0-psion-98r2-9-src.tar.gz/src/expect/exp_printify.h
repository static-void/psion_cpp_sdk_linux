#ifndef __EXP_PRINTIFY_H__
#define __EXP_PRINTIFY_H__

char *exp_printify _ANSI_ARGS_((char *));

#endif /* __EXP_PRINTIFY_H__ */
