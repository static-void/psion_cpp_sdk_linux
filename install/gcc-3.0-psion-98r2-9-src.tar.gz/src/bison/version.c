char *version_string = "GNU Bison version 1.25\n";
