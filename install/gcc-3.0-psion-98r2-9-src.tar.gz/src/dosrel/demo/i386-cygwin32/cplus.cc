#include <iostream.h>

main()
{
  int i;
  for (i =0;i < 10; i++)
    cout << "Hello World from C++" << i << "\n";

}

