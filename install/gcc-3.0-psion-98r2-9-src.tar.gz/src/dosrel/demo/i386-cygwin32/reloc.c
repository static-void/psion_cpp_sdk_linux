/* demo of building dll stuff */



