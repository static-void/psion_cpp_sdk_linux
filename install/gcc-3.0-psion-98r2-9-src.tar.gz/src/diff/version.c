/* Version number of GNU diff.  */

#include <config.h>

char const version_string[] = "2.7-psion-98r2";
