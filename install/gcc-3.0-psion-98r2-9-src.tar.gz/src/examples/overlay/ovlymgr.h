/*
 * Sample runtime overlay manager.
 */

/* Entry Points: */

int OverlayLoad   (unsigned long ovlyno);
int OverlayUnload (unsigned long ovlyno);

