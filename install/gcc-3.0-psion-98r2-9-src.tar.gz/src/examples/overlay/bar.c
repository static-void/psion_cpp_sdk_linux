static int barx = 'b' + 'a' + 'r';

int bar(int x)
{
  if (x)
    return barx;
  else
    return 0;
}
